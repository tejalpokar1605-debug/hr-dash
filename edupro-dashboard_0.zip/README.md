# EduPro Online Platform Dashboard

## Files
- `app.py` — the Streamlit dashboard
- `EduPro_Online_Platform.xlsx` — data source (must sit next to app.py, or in a `data/` subfolder)
- `requirements.txt` — Python dependencies

## Run locally
```bash
pip install -r requirements.txt
streamlit run app.py
```

## Deploy on Streamlit Community Cloud
1. Push `app.py`, `EduPro_Online_Platform.xlsx`, and `requirements.txt` to a GitHub repo (same folder).
2. On share.streamlit.io, point a new app at `app.py` in that repo.
3. The app auto-detects the Excel file in the repo root or a `data/` subfolder — no code changes needed.

## Pages
- Dashboard Overview — KPIs, category/level breakdowns, monthly revenue
- Course Demand Analysis
- Revenue Analysis
- Teacher Analysis
- Enrollment Prediction — interactive what-if calculator
- Model Performance — Random Forest metrics, feature importance, business insights
